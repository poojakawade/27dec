package com.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import com.StudentAdminApp.StudentAdminServiceApplication;

@SpringBootTest(classes = StudentAdminServiceApplication.class)
class StudentAdminServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
