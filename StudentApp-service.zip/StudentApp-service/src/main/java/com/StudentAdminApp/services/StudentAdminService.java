package com.StudentAdminApp.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.StudentAdminApp.entities.User;
import com.StudentAdminApp.exception.StudentAdminServiceException;
import com.StudentAdminApp.repositories.UserServiceRepository;



@Service
public class StudentAdminService {

   
    @Autowired
    private UserServiceRepository repo;
    
    @Autowired
	PasswordEncoder encoder;
    
    public List<User> getAllUsers(){
        return repo.findAll();
    }
    
    public User getUserById(long id) throws StudentAdminServiceException {
		Optional<User> optional = repo.findById(id);

		if (optional.isEmpty()) {
			throw new StudentAdminServiceException("User not found with id: " + id);
		} else {
			return optional.get();
		}
	}
    
    public User updateUser(User user) throws StudentAdminServiceException {
		if (repo.existsById(user.getId())) {
			user.setPassword(encoder.encode(user.getPassword()));
			return repo.save(user);
		} else {
			throw new StudentAdminServiceException("user not updated with Id: " + user.getId());
		}

	}

//    public Author saveAuthor(Author author){
//        return repo.save(author);
//    }
//    
}
