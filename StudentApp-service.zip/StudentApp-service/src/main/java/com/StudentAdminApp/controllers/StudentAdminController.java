package com.StudentAdminApp.controllers;

import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.StudentAdminApp.clients.StudentAdminServiceClient;
import com.StudentAdminApp.entities.User;
import com.StudentAdminApp.exception.StudentAdminServiceException;
import com.StudentAdminApp.models.Student;
import com.StudentAdminApp.services.StudentAdminService;

@RestController
@RequestMapping("/api/v1/studentapp/user")
//@CrossOrigin("*")
public class StudentAdminController {

	@Autowired
	private StudentAdminService service;
	
	@Autowired
	private StudentAdminServiceClient studentAdminServiceClient;
	
	@GetMapping("/getUser/{id}")
	public User getUser(@PathVariable long id) throws StudentAdminServiceException {
		return service.getUserById(id);
	}
	
	@PutMapping("/update/{id}")
	public User updateUser(@RequestBody User user,@PathVariable long id) throws StudentAdminServiceException {
		user.setId(id);
		return service.updateUser(user);
	}
	
	@GetMapping("/getstudents")
	public List<Student> getAllStudents() {
		return studentAdminServiceClient.getAllStudents();
	}
	
	@PostMapping("/savestudent")
	public Student saveEmployee(@RequestBody Student student) {
		return studentAdminServiceClient.saveStudent(student);
	}
	
	@GetMapping("/getemployees/{id}")
	public Student getEmployeebyId(@PathVariable int id) {
		return studentAdminServiceClient.getEmployeebyId(id);
	}
	
	@PutMapping("/updateemployees/{id}") 
	 public Student updateEmployee(@PathVariable int id,@RequestBody Student student) {
		student.setId(id);
		
		 return studentAdminServiceClient.updateEmployee(student); 
		 
	 }
	 
	 @DeleteMapping("/deleteemployees/{id}") 
	 @ResponseBody
	 public String deleteEmployee(@PathVariable int id) {
		 return studentAdminServiceClient.deleteEmployee(id); 
		 
	 }
	
	

//	@PostMapping("/signup")
//	public Author saveAuthor(@RequestBody Author author) {
//		return service.saveAuthor(author);
//	}

	
//	 @PostMapping("{authorId}/books") 
//	 public Book saveBook(@PathVariable int authorId,@RequestBody Book book) {
//		 book.setAuthorId(authorId);
//		 return bookServiceClient.SaveBook(book); 
//		 
//	 }
//	 
//	 @PutMapping("{authorId}/books/{bookId}") 
//	 public Book updateBook(@PathVariable int authorId,@PathVariable int bookId,@RequestBody Book book) {
//		 book.setAuthorId(authorId);
//		 book.setId(bookId);
//		 //System.out.println("BookId:"+book.getId());
//		 //System.out.println("Book authorId:"+book.getAuthorId());
//		// kafkaTemplate.send(TOPIC,book);
//		 //System.out.println("Published successfully :"+book.toString());
//		 return bookServiceClient.updateBook(book); 
//		 
//	 }
//	 
//	 @DeleteMapping("/books/{bookId}") 
//	 @ResponseBody
//	 public void deleteBook(@PathVariable int bookId) {
//		 bookServiceClient.deleteBook(bookId); 
//		 
//	 }
	 
	 
	 
	

}
