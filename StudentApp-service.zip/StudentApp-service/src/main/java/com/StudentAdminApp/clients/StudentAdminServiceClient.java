package com.StudentAdminApp.clients;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;

import com.StudentAdminApp.models.Student;

import feign.Headers;

@FeignClient(name = "StudentService", url = "localhost:9191")
public interface StudentAdminServiceClient {
	
	@GetMapping("/api/v1/std/getstudents")
	public List<Student> getAllStudents();
	
	@PostMapping("/api/v1/std/savestd")
	@Headers("Content-Type: application/json")
	public Student saveStudent(Student student);
	
	@GetMapping("/api/v1/emp/getemployees/{id}")
	public Student getEmployeebyId(@PathVariable int id);

	@PutMapping("/api/v1/emp/updateemployees") 
	public Student updateEmployee(Student student);

	@DeleteMapping("/api/v1/emp/deleteemployees/{id}") 
	public String deleteEmployee(@PathVariable int id);

	
}
