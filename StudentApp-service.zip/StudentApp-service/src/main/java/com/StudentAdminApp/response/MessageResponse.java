package com.StudentAdminApp.response;

public class MessageResponse {

	private String message;

	public MessageResponse(String message) {
		// TODO Auto-generated constructor stub
		this.message=message;
	}
	
	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	
}
