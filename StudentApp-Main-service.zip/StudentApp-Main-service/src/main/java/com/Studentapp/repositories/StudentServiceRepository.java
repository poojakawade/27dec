package com.Studentapp.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.Studentapp.entities.Student;

public interface StudentServiceRepository extends JpaRepository<Student, Integer> {

//	List<Book> findByCategoryAndAuthorAndPriceAndPublisherAndStatus(String category, String author, double price, 
//			String publisher,String status);
//	
//	List<Book> findByAuthorId(int authorId);
//	
//	@Query(value="select * from book b where b.id in (select book_id from subscribe where reader_email=:emailID) and b.status='Active'",nativeQuery = true)
//	List<Book> findbookbyemailID(String emailID);
//	
//	@Query(value="select * from book b where b.id = (select book_id from subscribe where reader_email=:emailID and book_id=:bookId ) and b.status='Active'",nativeQuery = true)
//	List<Book> getBooksbyemailIDnbookID(String emailID,int bookId);
//	
//	@Query(value="select * from book b where b.id = (select book_id from subscribe where reader_email=:emailID and id=:payId ) and b.status='Active'",nativeQuery = true)
//	List<Book> getBooksbypayId(String emailID,int payId);
//	
//	@Query(value="select s.datetime from subscribe s where s.reader_email=:emailID and  book_id=:bookId ",nativeQuery = true)
//	LocalDateTime getRefund(String emailID,int bookId);
//	
//	@Query(value="select s.id from subscribe s where s.reader_email=:emailID and  book_id=:bookId ",nativeQuery = true)
//	int getkeyId(String emailID,int bookId);
//	
//	@Query(value="select e.reader_email from subscribe e where e.book_id=:bookId ",nativeQuery = true)
//	List<String> getauthemailIds(int bookId);
//	
//	@Modifying
//	@Transactional
//	@Query(value="update subscribe s set s.refund='Y' where s.id=:id",nativeQuery = true)
//	void updateRefund(int id);
	// List<Movie> findAll();
	// Movie findById(int id);
	// Movie save(Movie m);
	// Movie delete(int id);
}

// interface MyRepository<T, P>{
//     List<T> findAll();
//     T findById(P id);
//     T save(T m);
//     T delete(P id);
// }

// class MyDemoRepository implements MyRepository<Object, String>{

//     @Override
//     public List<Object> findAll() {
//         // TODO Auto-generated method stub
//         return null;
//     }

//     @Override
//     public Object findById(String id) {
//         // TODO Auto-generated method stub
//         return null;
//     }

//     @Override
//     public Object save(Object m) {
//         // TODO Auto-generated method stub
//         return null;
//     }

//     @Override
//     public Object delete(String id) {
//         // TODO Auto-generated method stub
//         return null;
//     }}

// class MyMovieRepository implements MyRepository<Movie, Integer>{

//     @Override
//     public List<Movie> findAll() {
//         // TODO Auto-generated method stub
//         return null;
//     }

//     @Override
//     public Movie findById(Integer id) {
//         // TODO Auto-generated method stub
//         return null;
//     }

//     @Override
//     public Movie save(Movie m) {
//         // TODO Auto-generated method stub
//         return null;
//     }

//     @Override
//     public Movie delete(Integer id) {
//         // TODO Auto-generated method stub
//         return null;
//     }

// }

// // class BookRepository {
// //     List<Book> findAll();
// //     Book findById(int id);
// //     Book save(Book m);
// //     Book delete(int id);
// // }

// // class PaymentRepository {
// //     List<Payment> findAll();
// //     Payment findById(String id);
// //     Payment save(Payment m);
// //     Payment delete(String id);
// // }
