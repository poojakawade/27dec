package com.Studentapp.exception;

public class StudentServiceException extends Exception {

	public StudentServiceException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public StudentServiceException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public StudentServiceException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public StudentServiceException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public StudentServiceException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	
}
