package com.Studentapp.exception.handler;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.Studentapp.exception.StudentServiceException;


@ControllerAdvice
public class GlobalExceptionHandler {

	@ExceptionHandler(StudentServiceException.class)
	public ResponseEntity<?> handleException(StudentServiceException e) {
		return ResponseEntity.ok(new ErrorResponse(e.getMessage(), e.getClass().toString()));
	}
}
