package com.Studentapp.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.Studentapp.entities.Student;
import com.Studentapp.exception.StudentServiceException;
import com.Studentapp.services.StudentService;

@RestController
// @CrossOrigin(origins = {"https://hoppscotch.io"})
//@CrossOrigin("*")
@RequestMapping("/api/v1/std")
public class StudentController {

	@Autowired
	private StudentService service;

	
	@GetMapping("/getstudents")
	public List<Student> getAllStudents() {
		return service.getAllStudents();
	}

	
	@PostMapping("/savestd")
	public Student saveStudent(@RequestBody Student student) {
		return service.saveStudent(student);
	}
	
	@GetMapping("/getemployees/{id}")
	public Student getEmployeebyId(@PathVariable int id) throws StudentServiceException {
		return service.getEmployeebyId(id);
	}

	@PutMapping("/updateemployees")
	public Student updateEmployee(@RequestBody Student employee) throws StudentServiceException {
		return service.updateEmployee(employee);
	}
	
	@DeleteMapping("/deleteemployees/{id}") 
	@ResponseBody
	public String delete(@PathVariable int id) throws StudentServiceException 
	{  
		return service.delete(id);
	}
	 

}
