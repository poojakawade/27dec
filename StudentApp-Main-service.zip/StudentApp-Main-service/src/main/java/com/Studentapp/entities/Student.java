package com.Studentapp.entities;



import java.time.LocalDate;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Student {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;

	private String firstName;
	private String lastName;
	private String emailId;
	private LocalDate dob;
	private String address;
	private Double sscMarks;
	private Double hscMarks;
	private String Status;
	private String logoUrl;

	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public LocalDate getDob() {
		return dob;
	}
	public void setDob(LocalDate dob) {
		this.dob = dob;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public Double getSscMarks() {
		return sscMarks;
	}
	public void setSscMarks(Double sscMarks) {
		this.sscMarks = sscMarks;
	}
	public Double getHscMarks() {
		return hscMarks;
	}
	public void setHscMarks(Double hscMarks) {
		this.hscMarks = hscMarks;
	}
	public String getStatus() {
		return Status;
	}
	public void setStatus(String status) {
		Status = status;
	}
	public String getLogoUrl() {
		return logoUrl;
	}
	public void setLogoUrl(String logoUrl) {
		this.logoUrl = logoUrl;
	}
	public Student() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Student(String firstName, String lastName, String emailId, LocalDate dob, String address, Double sscMarks,
			Double hscMarks, String status, String logoUrl) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.emailId = emailId;
		this.dob = dob;
		this.address = address;
		this.sscMarks = sscMarks;
		this.hscMarks = hscMarks;
		this.Status = status;
		this.logoUrl = logoUrl;
	}
	
	
	
	
	
	
	
	
	

}
