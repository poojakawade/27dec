package com.Studentapp.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Studentapp.entities.Student;
import com.Studentapp.exception.StudentServiceException;
import com.Studentapp.repositories.StudentServiceRepository;

@Service
public class StudentService {

	@Autowired
	private StudentServiceRepository repo;
	

	public List<Student> getAllStudents() {
		return repo.findAll();
	}


	public Student getEmployeebyId(int id) throws StudentServiceException {
		Optional<Student> optional = repo.findById(id);

		if (optional.isEmpty()) {
			throw new StudentServiceException("Employee not found with id: " + id);
		} else {
			return optional.get();
		}
	}

	public Student saveStudent(Student student) {
		return repo.save(student);
	}

	public Student updateEmployee(Student employee) throws StudentServiceException {
		if (repo.existsById(employee.getId())) {
			return repo.save(employee);
		} else {
			throw new StudentServiceException("Employee is not found with Id: " + employee.getId());
		}

	}

	public String delete(int id) throws StudentServiceException {

		Optional<Student> optional = repo.findById(id);

		if (optional.isEmpty()) {
			throw new StudentServiceException("Student not found with id: " + id);
		} else {
			repo.deleteById(id);
			return "Student is deleted Successfully!!";
		}
	}

}
