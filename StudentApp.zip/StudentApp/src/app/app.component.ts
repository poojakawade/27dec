import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Book } from "./book";
import { BookService } from './services/book.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit {
  title = 'DigitalBook';

  //book:Book | null |undefined;

  public books: Book[] = [];

  constructor(private bookService: BookService){}

  ngOnInit(){
    //this.getBooks();
  }

  // public getBooks():void{
  //   this.bookService.getBooks().subscribe(
  //     (Response:Book[])=>{
  //       this.books=Response;
  //     },
  //     (error:HttpErrorResponse)=>{
  //       alert(error.message);
        
  //     } 
  //   );
  // }

  public onAddBook(addForm: NgForm): void {
    // document.getElementById('add-book-form').click();
    // this.bookService.addBook(authorId,addForm.value).subscribe(
    //   (response: Book) => {
    //     console.log(response);
    //     this.getBooks();
    //     addForm.reset();
    //   },
    //   (error: HttpErrorResponse) => {
    //     alert(error.message);
    //     addForm.reset();
    //   }
    // );
  }


  public onOpenModal(book: Book, mode: string): void {
    const container = document.getElementById('main-container');
    const button = document.createElement('button');
    button.type = 'button';
    button.style.display = 'none';
    button.setAttribute('data-toggle', 'modal');
    if (mode === 'add') {
      button.setAttribute('data-target', '#addBookModal');
    }
    if (mode === 'edit') {
      //this.editEmployee = book;
      button.setAttribute('data-target', '#updateBookModal');
    }
    if (mode === 'delete') {
      //this.deleteEmployee = book;
      button.setAttribute('data-target', '#deleteBookModal');
    }
    container?.appendChild(button);
    button.click();
  }
  
}
