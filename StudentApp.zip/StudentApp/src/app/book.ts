export interface Book{
    id:number;
	title:string;
	category:string;
	price:number;
	author:string;
	publisher:string;
	content:string;
	status:string;
	authorId:number;
	logoUrl:string;
}