export interface SubscribeBook{
    id:number;
    bookId:number;
	readerName:string;
	readerEmail:string;
	
}