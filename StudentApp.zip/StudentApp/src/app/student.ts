export interface Student{
    id:number;
	firstName:string;
	lastName:string;
	emailId:string;
	dob:Date;
	address:string;
	sscMarks:number;
	hscMarks:number;
	Status:string;
	logoUrl:string;
}