import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Book } from 'src/app/book';
import { BookService } from 'src/app/services/book.service';
import { LoginService } from 'src/app/services/login.service';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit {

  public books: Book[] = [];
  authorName:any
  public editBook:Book;
  public deleteBook: Book;

  constructor(private bookService: BookService,private loginService:LoginService) { }

  ngOnInit(): void {
    this.getBooks();

  }

  public getBooks():void{
    console.log(this.loginService.getId())
    this.bookService.getAuthorBooks(+this.loginService.getId()).subscribe(
      (Response:Book[])=>{
        this.books=Response;
        this.authorName=Response[0].author

      },
      (error:HttpErrorResponse)=>{
        alert(error.message);
        
      } 
    );
  }

  public onAddBook(addForm: NgForm): void {
    document.getElementById('add-book-form').click();
    this.bookService.addBook(+this.loginService.getId(),addForm.value).subscribe(
      (response: Book) => {
        console.log(response);
        this.getBooks();
        addForm.reset();
      },
      (error: HttpErrorResponse) => {
        alert(error.message);
        addForm.reset();
      }
    );
  }

  public onUpdateBook(id:number,book:Book): void {
    document.getElementById('add-book-form').click();
    this.bookService.updateBook(+this.loginService.getId(),id,book).subscribe(
      (response: Book) => {
        console.log(response);
        this.getBooks();
      },
      (error: HttpErrorResponse) => {
        alert(error.message);
      }
    );
  }

  public onDeleteBook(id:number): void {
    document.getElementById('add-book-form').click();
    this.bookService.deleteBook(id).subscribe(
      (response: string) => {
        console.log(response);
        this.getBooks();
      },
      (error: HttpErrorResponse) => {
        alert(error.message);
      }
    );
  }

  public onOpenModal(book: Book, mode: string): void {
    const container = document.getElementById('main-container');
    const button = document.createElement('button');
    button.type = 'button';
    button.style.display = 'none';
    button.setAttribute('data-toggle', 'modal');
    if (mode === 'add') {
      button.setAttribute('data-target', '#addBookModal');
    }
    if (mode === 'edit') {
      this.editBook = book;
      button.setAttribute('data-target', '#updateBookModal');
    }
    if (mode === 'delete') {
      this.deleteBook = book;
      button.setAttribute('data-target', '#deleteBookModal');
    }
    container?.appendChild(button);
    button.click();
  }

}
