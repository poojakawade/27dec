import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { StudentService } from 'src/app/services/student.service';
import { Student } from 'src/app/student';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {

  public students: Student[] = [];


  constructor(private studentService: StudentService,private router:Router,
    private route:ActivatedRoute) { }

  ngOnInit(): void {
    this.getStudents();
  }

  public getStudents():void{
    this.studentService.getStudents().subscribe(
      (Response:Student[])=>{
        this.students=Response;

      },
      (error:HttpErrorResponse)=>{
        alert(error.message);
        
      } 
    );
  }

  // public searchBooks(key: string): void {
  //   console.log(key);
  //   const results: Book[] = [];
  //   for (const book of this.books) {
  //     if (book.category.toLowerCase().indexOf(key.toLowerCase()) !== -1
  //     || book.author.toLowerCase().indexOf(key.toLowerCase()) !== -1
  //     // || book.price!== -1
  //     || book.publisher.toLowerCase().indexOf(key.toLowerCase()) !== -1) {
  //       results.push(book);
  //     }
  //   }
  //   this.books = results;
  //   console.log(this.books);
  //   if (results.length === 0 || !key) {
  //     this.getBooks();
  //   }
  // }

  // public onSubcribeBook(subscribeForm: NgForm): void {
  //   document.getElementById('add-book-form').click();
  //   console.log("subscribeForm.value"+subscribeForm.value)
  //   this.bookService.subscribeBook(subscribeForm.value).subscribe(
  //     (response: SubscribeBook) => {
  //       console.log(response);
  //       this.getBooks();
  //       subscribeForm.reset();
  //       //window.location.href="/reader"
  //       this.router.navigate(['/reader']);

  //     },
  //     (error: HttpErrorResponse) => {
  //       alert(error.message);
  //       subscribeForm.reset();
  //     }
  //   );
  // }

  // public onOpenModal(subscribeBook: SubscribeBook, mode: string): void {
  //   const container = document.getElementById('main-container');
  //   const button = document.createElement('button');
  //   button.type = 'button';
  //   button.style.display = 'none';
  //   button.setAttribute('data-toggle', 'modal');
  //   if (mode === 'subscribe') {
  //     //this.subBook = subscribeBook;
  //     button.setAttribute('data-target', '#subscribeBookModal');
  //   }
  //   if (mode === 'edit') {
  //     //this.editBook = book;
  //     button.setAttribute('data-target', '#updateBookModal');
  //   }
  //   if (mode === 'delete') {
  //     //this.deleteBook = book;
  //     button.setAttribute('data-target', '#deleteBookModal');
  //   }
  //   container?.appendChild(button);
  //   button.click();
  // }

}
