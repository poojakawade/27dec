import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, NgForm } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { LoginService } from 'src/app/services/login.service';
import { StudentService } from 'src/app/services/student.service';
import { User } from 'src/app/user';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.scss']
})
export class RegisterComponent implements OnInit {

  public user: User[] = [];
  //userForm:FormGroup;

  constructor(private studentService:StudentService,private router:Router,
    private route:ActivatedRoute) { 
   
  }

  ngOnInit(): void {
  }

  onsubmit(addForm: NgForm){
    console.log(addForm.value);
    this.studentService.addStudent(addForm.value).subscribe(
      (response:any) => {
        console.log(response);
        //window.location.href="/login"
        this.router.navigate(['/']);
        //addForm.reset();
      },
      (error: HttpErrorResponse) => {
        alert(error.message);
        addForm.reset();
      }
    );
    
  }
}
