import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { Observable } from "rxjs";
import { environment } from "src/environments/environment";
import { Message } from "../message";
import { SubscribeBook } from "../SubscribeBook";
import { Book } from "./../book";

@Injectable({"providedIn": "root"})
export class BookService{
    //private apiServerUrl = environment.apiBaseUrl;

    constructor(private http: HttpClient){}

    public getBooks():Observable<Book[]>{
        return this.http.get<Book[]>(`https://948lyx95sa.execute-api.ap-northeast-1.amazonaws.com/Dev/books`);

    }
    public getAuthorBooks(authorId:number):Observable<Book[]>{
        return this.http.get<Book[]>(`http://52.192.210.116:8181/api/v1/digitalbooks/author/getBooks/${authorId}`);

    }
    public addBook(authorId:number,book:Book): Observable<Book>{
        return this.http.post<Book>(`http://52.192.210.116:8181/api/v1/digitalbooks/author/${authorId}/books`,book);
    }
    public updateBook(authorId:number,bookId:number,book:Book): Observable<Book>{
        return this.http.put<Book>(`http://52.192.210.116:8181/api/v1/digitalbooks/author/${authorId}/books/${bookId}`,book);
    }

    public deleteBook(bookId:number): Observable<string>{
        return this.http.delete<string>(`http://52.192.210.116:8181/api/v1/digitalbooks/author/books/${bookId}`);
    }
    public subscribeBook(subscribeBook:SubscribeBook): Observable<SubscribeBook>{
        return this.http.post<SubscribeBook>(`http://52.192.210.116:7171/api/v1/digitalbooks/books/buy`,subscribeBook);
    }

    public getBooksbyEmailId(emailId:string):Observable<Book[]>{
        return this.http.get<Book[]>(`https://kol3we8nbh.execute-api.ap-northeast-1.amazonaws.com/Dev/${emailId}`);

    }

    public getBooksbyEmailIdnBookId(emailId:string,bookId:number):Observable<Book[]>{
        return this.http.get<Book[]>(`http://52.192.210.116:7171/api/v1/digitalbooks/readers/${emailId}/books/${bookId}`);

    }

    public getBooksbyEmailIdnPayId(emailId:string,payId:number):Observable<Book[]>{
        return this.http.get<Book[]>(`http://52.192.210.116:7171/api/v1/digitalbooks/readers/${emailId}/bookss/?payId=${payId}`);

    }

    public getRefundsbyEmailIdnbookId(emailId:string,bookId:number):Observable<Message>{
        return this.http.get<Message>(`http://52.192.210.116:7171/api/v1/digitalbooks/readers/${emailId}/books/${bookId}/refund`);

    }
   
}