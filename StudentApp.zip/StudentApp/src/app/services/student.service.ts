import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { Observable } from "rxjs";
import { environment } from "src/environments/environment";
import { Student } from "../student";

@Injectable({"providedIn": "root"})
export class StudentService{
    //private apiServerUrl = environment.apiBaseUrl;

    constructor(private http: HttpClient){}

    public getStudents():Observable<Student[]>{
        return this.http.get<Student[]>(`http://localhost:9000/api/v1/studentapp/user/getstudents`);

    }
   
    public addStudent(student:Student): Observable<Student>{
        return this.http.post<Student>(`http://localhost:9000/api/v1/studentapp/user/savestudent`,student);
    }
   
   
}